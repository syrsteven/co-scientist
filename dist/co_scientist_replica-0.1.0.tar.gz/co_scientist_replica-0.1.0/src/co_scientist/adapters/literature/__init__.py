"""Literature provider adapters."""
