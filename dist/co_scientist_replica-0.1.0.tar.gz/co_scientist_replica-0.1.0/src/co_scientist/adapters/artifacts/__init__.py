"""Artifact persistence adapters."""
