"""Typed agent execution contracts."""
